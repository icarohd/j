public class Cliente {
    private String nombre;
    private int TipoPlan;
    private int min_conectado;
    private int monto_pagar;

    public Cliente(String nombre, int TipoPlan, int min_conectado, int monto_pagar) {
        this.nombre = nombre;
        this.TipoPlan = TipoPlan;
        this.min_conectado = min_conectado;
        this.monto_pagar = monto_pagar;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTipoPlan() {
        return TipoPlan;
    }

    public void setTipoPlan(int TipoPlan) {
        this.TipoPlan = TipoPlan;
    }

    public int getMin_conectado() {
        return min_conectado;
    }

    public void setMin_conectado(int min_conectado) {
        this.min_conectado = min_conectado;
    }

    public int getMonto_pagar() {
        return monto_pagar;
    }

    public void setMonto_pagar(int monto_pagar) {
        this.monto_pagar = monto_pagar;
    }
    
    
    
}
