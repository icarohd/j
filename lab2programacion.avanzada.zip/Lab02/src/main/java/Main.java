import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int x=0;
        int tipoplan;
            Scanner leer = new Scanner(System.in);
            TipoPlan p = new TipoPlan("Preferencial", 15000, 80,0);
            TipoPlan n = new TipoPlan("Normal", 7000, 120,0);
            Cliente c = new Cliente("",0,0,0);
        do{
    
            do{
                System.out.println("Ingrese Su Nombre:");
                String nombre = leer.nextLine();
                System.out.println("Ingrese el plan 1 para Preferencial 2 para Normal");
                tipoplan = leer.nextInt();
            }
            //verificador para valores distintos de 1 y 2
            while ((tipoplan < 1)||(tipoplan > 2));
            if (tipoplan == 1){
                p.setCant_cliente(p.getCant_cliente()+1);
                System.out.println("Ingrese La cantidad de Minutos Hablados");
                int min_conectado = leer.nextInt();
                //calculo total
                int total = ((min_conectado*p.getCosto_minuto())+p.getCosto_fijo());
                c.setMonto_pagar(total);
                System.out.println("El monto a pagar total es de :"+ c.getMonto_pagar()+ " pesos");
                }
            else{
                n.setCant_cliente(n.getCant_cliente()+1);
                System.out.println("Ingrese La cantidad de Minutos Hablados");
                int min_conectado = leer.nextInt();
                //calculo total
                int total = ((min_conectado*n.getCosto_minuto())+n.getCosto_fijo());
                c.setMonto_pagar(total);
                System.out.println("El monto a pagar total es de :"+ c.getMonto_pagar()+ " pesos");


            }

        System.out.println("Seguir .0 Salir.1");
        x = leer.nextInt();
    }while(x==0);
    System.out.println("La Cantidad de Personas de Tipo Plan Preferencial es de :"+ p.getCant_cliente());
    System.out.println("La Cantidad de Personas de Tipo Plan Normal es de :"+ n.getCant_cliente());
    } 
}
