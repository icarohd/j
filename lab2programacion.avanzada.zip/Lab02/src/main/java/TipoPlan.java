
public class TipoPlan {
    private String Nombreplan;
    private int costo_fijo;
    private int costo_minuto;
    private int cant_cliente;

    public TipoPlan(String Nombreplan, int costo_fijo, int costo_minuto, int cant_cliente) {
        this.Nombreplan = Nombreplan;
        this.costo_fijo = costo_fijo;
        this.costo_minuto = costo_minuto;
        this.cant_cliente = cant_cliente;
    }

    public String getNombreplan() {
        return Nombreplan;
    }

    public void setNombreplan(String Nombreplan) {
        this.Nombreplan = Nombreplan;
    }

    public int getCosto_fijo() {
        return costo_fijo;
    }

    public void setCosto_fijo(int costo_fijo) {
        this.costo_fijo = costo_fijo;
    }

    public int getCosto_minuto() {
        return costo_minuto;
    }

    public void setCosto_minuto(int costo_minuto) {
        this.costo_minuto = costo_minuto;
    }

    public int getCant_cliente() {
        return cant_cliente;
    }

    public void setCant_cliente(int cant_cliente) {
        this.cant_cliente = cant_cliente;
    }
    
    
}